#include <iostream>
#include "fifa.h"
using namespace std;

int main(){
    Fifa f;
    f.menu();
    
    return 0;
}