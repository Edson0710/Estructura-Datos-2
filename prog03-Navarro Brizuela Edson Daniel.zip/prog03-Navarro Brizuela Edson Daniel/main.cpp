#include "tickets.h"

int main(){
    Tickets tickets = Tickets();
    tickets.menu();
    return 0;
}